module.exports = {
    modelBaseDirectory:"app_api/database/models",
    models: ["*.js", "!db.js"],
    data: "data",
    db: "mongodb://localhost:27017/travlr",
};